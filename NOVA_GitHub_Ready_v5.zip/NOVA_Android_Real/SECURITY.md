# Security policy

- Never commit API keys, passwords, access tokens, or `.env` files.
- If a key has been pasted into a chat, repository, screenshot, or public issue, revoke/rotate it.
- Android screen capture requires the user's explicit Android system consent. Do not attempt hidden capture.
- Report security issues privately to the repository owner rather than posting secrets in public issues.
