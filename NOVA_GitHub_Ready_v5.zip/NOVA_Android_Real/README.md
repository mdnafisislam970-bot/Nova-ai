# NOVA AI — Android screen-aware starter

Native Kotlin Android starter for a Bangla assistant. The current app includes user-approved MediaProjection screen capture, on-device OCR with ML Kit, truthful capture status, Bangla text-to-speech, and an optional floating bubble.

> **Scope notice:** This repository is a starter, not a finished all-purpose AI agent. The current Android screen flow extracts visible text with OCR. It does **not** yet send screenshots/text to a Gemini AI backend or implement general AI reasoning, autonomous phone control, or reliable game predictions. The `backend/` folder is a separate starter and is not yet wired into the Android UI.

## Requirements

- Android Studio with Android SDK Platform 35
- JDK 17
- Internet for Gradle dependencies on first build
- Android 8.0 (API 26) or newer for the current app configuration

## Build in Android Studio

1. Download/clone this repository.
2. Open the `NOVA_Android_Real` project folder (the folder containing `settings.gradle.kts`).
3. Let Gradle sync and install SDK 35 if Android Studio asks.
4. Select the `app` run configuration and run on a real Android phone.
5. Tap **স্ক্রিন দেখা চালু করো** and accept Android's own screen-sharing prompt.
6. To use the floating N bubble, grant **Display over other apps**, return to NOVA, then tap the bubble button again.

## Build from command line

From the project root, with Gradle 8.7 and JDK 17 installed:

```bash
gradle --no-daemon :app:assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Publish on GitHub

1. Create a new **empty** GitHub repository (do not add a README or license during creation).
2. Extract the ZIP and open a terminal in the folder containing `settings.gradle.kts`.
3. Run the following commands, replacing `YOUR-USERNAME/YOUR-REPO`:

```bash
git init
git add .
git commit -m "Initial NOVA Android project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPO.git
git push -u origin main
```

4. Open the repository's **Actions** tab. The Android Build workflow compiles the debug APK and uploads it as an artifact. Download it from the successful workflow run.

## Troubleshooting

- **SDK not found:** open the project in Android Studio and install Android SDK Platform 35. Do not commit `local.properties`.
- **Gradle sync error:** confirm JDK 17 and Gradle 8.7, then use Android Studio's *Sync Project with Gradle Files*.
- **Screen capture says unavailable:** stop sharing and start it again using the Android system prompt. Protected/secure screens may not be capturable.
- **Bangla voice unavailable:** install/download a Bengali voice in Android Text-to-Speech settings; device voice support varies.
- **Overlay not visible:** grant the OS-level *Display over other apps* permission.

## Privacy and limitations

- Screen sharing is explicit and user-controlled; Android may stop it at any time.
- OCR can miss small text, animation, images, or protected content.
- NOVA must not claim it can see the screen unless it has received a real frame.
- No system can guarantee a zero-error build on every device. GitHub Actions is included to catch compilation failures after each push.
- Do not embed AI API keys in Kotlin, HTML, GitHub, or the APK. Use a secured backend or Firebase AI Logic with appropriate App Check/security configuration before adding cloud AI.
- No betting, wagering, or financial outcome is guaranteed.
