package com.nova.assistant

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var extracted: TextView
    private lateinit var nameInput: EditText
    private var tts: TextToSpeech? = null
    private val captureRequest = 4201
    private var receiverRegistered = false

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != ScreenCaptureService.ACTION_STATE) return
            val canSee = intent.getBooleanExtra("canSee", false)
            val text = intent.getStringExtra("screenText").orEmpty()
            status.text = if (canSee) "হ্যাঁ ${getName()} ভাই, আমি তোমার স্ক্রিন দেখতে পারছি।" else "${getName()} ভাই, আমি এখন তোমার স্ক্রিন দেখতে পারছি না।"
            if (text.isNotBlank()) extracted.text = "স্ক্রিনে পাওয়া লেখা:\n$text" else if (canSee) extracted.text = "স্ক্রিনের ছবি পাওয়া গেছে। লেখা পড়ার জন্য স্ক্রিন পরিষ্কার/স্থির রাখো।"
            speak(status.text.toString())
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        val filter = IntentFilter(ScreenCaptureService.ACTION_STATE)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenReceiver, filter, RECEIVER_NOT_EXPORTED) else @Suppress("DEPRECATION") registerReceiver(screenReceiver, filter)
        receiverRegistered = true
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 28, 22, 22); setBackgroundColor(0xFF0B1720.toInt()) }
        val title = TextView(this).apply { text = "NOVA AI"; textSize = 28f; setTextColor(0xFF53E0D0.toInt()); gravity = Gravity.CENTER; setPadding(0, 8, 0, 8) }
        val subtitle = TextView(this).apply { text = "Screen-aware Bangla assistant"; textSize = 14f; setTextColor(0xFFB7C9D3.toInt()); gravity = Gravity.CENTER; setPadding(0, 0, 0, 18) }
        nameInput = EditText(this).apply { hint = "তোমার নাম (যেমন Nafis)"; setSingleLine(); setTextColor(-1); setHintTextColor(0xFF8EA4AF.toInt()) }
        status = TextView(this).apply { text = "নাফিস ভাই, এখনো স্ক্রিন শেয়ার চালু হয়নি।"; textSize = 17f; setTextColor(-1); setPadding(0, 18, 0, 18) }
        extracted = TextView(this).apply { text = "স্ক্রিনের লেখা এখানে দেখা যাবে।"; textSize = 14f; setTextColor(0xFFD2E0E7.toInt()); setPadding(0, 8, 0, 16) }
        fun btn(label: String, action: () -> Unit) = Button(this).apply { text = label; setOnClickListener { action() } }
        root.addView(title); root.addView(subtitle); root.addView(nameInput, ViewGroup.LayoutParams(-1, -2)); root.addView(status)
        root.addView(btn("স্ক্রিন দেখা চালু করো", ::requestScreenShare))
        root.addView(btn("স্ক্রিন দেখা বন্ধ করো") { stopService(Intent(this, ScreenCaptureService::class.java)); status.text = "${getName()} ভাই, স্ক্রিন শেয়ার বন্ধ। এখন আমি দেখতে পারছি না।"; speak(status.text.toString()) })
        root.addView(btn("Floating NOVA আইকন চালু করো", ::enableBubble))
        root.addView(btn("মন খারাপ 😔") { val line = "${getName()} ভাই, একটু ধীরে শ্বাস নাও। সবকিছু একসাথে ঠিক করতে হবে না। আমি তোমার কথা শুনছি—একটা একটা করে বলো।"; status.text = line; speak(line) })
        root.addView(extracted)
        val note = TextView(this).apply { text = "গোপনীয়তা: Android-এর স্ক্রিন-শেয়ার অনুমতি তোমাকেই দিতে হবে। শেয়ার বন্ধ হলে NOVA আর স্ক্রিন দেখতে পারবে না। OCR লেখা পড়ার চেষ্টা করে; সব অ্যাপ/ছবি নিখুঁতভাবে বুঝতে পারবে—এমন নিশ্চয়তা নেই।"; textSize = 12f; setTextColor(0xFF8EA4AF.toInt()); setPadding(0, 14, 0, 0) }
        root.addView(note)
        val scroll = ScrollView(this); scroll.addView(root); setContentView(scroll)
    }

    private fun getName(): String = nameInput.text.toString().trim().ifBlank { "Nafis" }

    private fun requestScreenShare() {
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mgr.createScreenCaptureIntent(), captureRequest)
    }

    @Deprecated("Activity result API kept for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest) {
            if (resultCode == RESULT_OK && data != null) {
                val service = Intent(this, ScreenCaptureService::class.java).apply { putExtra("resultCode", resultCode); putExtra("projectionData", data) }
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
                status.text = "${getName()} ভাই, অনুমতি পেয়েছি—স্ক্রিন ক্যাপচার শুরু করছি…"
            } else {
                status.text = "${getName()} ভাই, স্ক্রিন দেখার অনুমতি পাওয়া যায়নি। তাই আমি দেখতে পারছি না।"
                speak(status.text.toString())
            }
        }
    }

    private fun enableBubble() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            status.text = "Floating আইকনের জন্য পরের স্ক্রিনে NOVA-কে ‘Display over other apps’ অনুমতি দাও, তারপর ফিরে এসে আবার চাপো।"
            return
        }
        startService(Intent(this, FloatingBubbleService::class.java))
        status.text = "Floating NOVA আইকন চালু হয়েছে।"
    }

    private fun speak(text: String) { tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nova-${System.currentTimeMillis()}") }
    override fun onInit(statusCode: Int) { if (statusCode == TextToSpeech.SUCCESS) tts?.language = Locale("bn", "BD") }
    override fun onDestroy() { if (receiverRegistered) unregisterReceiver(screenReceiver); tts?.stop(); tts?.shutdown(); super.onDestroy() }
}
