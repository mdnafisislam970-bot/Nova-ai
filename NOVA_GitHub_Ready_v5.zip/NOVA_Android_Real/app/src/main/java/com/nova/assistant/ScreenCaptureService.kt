package com.nova.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.atomic.AtomicBoolean

class ScreenCaptureService : Service() {
    companion object { const val ACTION_STATE = "com.nova.assistant.SCREEN_STATE"; private const val CHANNEL = "nova_screen_capture"; private const val NOTIFICATION_ID = 3812 }
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var worker: HandlerThread? = null
    private var handler: Handler? = null
    private val processing = AtomicBoolean(false)
    private var lastProcessed = 0L
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        startForeground(NOTIFICATION_ID, notification())
        val code = intent?.getIntExtra("resultCode", 0) ?: 0
        val data = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra("projectionData", Intent::class.java) else @Suppress("DEPRECATION") intent?.getParcelableExtra("projectionData")
        if (code == 0 || data == null) { broadcast(false, ""); stopSelf(); return START_NOT_STICKY }
        try {
            val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = mgr.getMediaProjection(code, data)
            projection?.registerCallback(object : MediaProjection.Callback() { override fun onStop() { broadcast(false, ""); stopSelf() } }, Handler(mainLooper))
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION") (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
            val width = metrics.widthPixels.coerceAtLeast(1); val height = metrics.heightPixels.coerceAtLeast(1); val density = metrics.densityDpi
            worker = HandlerThread("NOVA-OCR").also { it.start() }; handler = Handler(worker!!.looper)
            reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            reader!!.setOnImageAvailableListener({ source ->
                val now = System.currentTimeMillis()
                if (now - lastProcessed < 1800 || !processing.compareAndSet(false, true)) { source.acquireLatestImage()?.close(); return@setOnImageAvailableListener }
                lastProcessed = now
                val image = source.acquireLatestImage()
                if (image == null) { processing.set(false); return@setOnImageAvailableListener }
                // A real image frame has been acquired: only now report that screen capture works.
                broadcast(true, "")
                try {
                    val input = InputImage.fromMediaImage(image, 0)
                    recognizer.process(input).addOnSuccessListener { result ->
                        val text = result.text.take(3500)
                        broadcast(true, text)
                    }.addOnFailureListener { broadcast(true, "") }.addOnCompleteListener { image.close(); processing.set(false) }
                } catch (_: Exception) { image.close(); processing.set(false) }
            }, handler)
            display = projection?.createVirtualDisplay("NOVA Screen Capture", width, height, density, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, handler)
            if (display == null) { broadcast(false, ""); stopSelf() }
        } catch (_: Exception) { broadcast(false, ""); stopSelf() }
        return START_NOT_STICKY
    }

    private fun broadcast(canSee: Boolean, text: String) { sendBroadcast(Intent(ACTION_STATE).setPackage(packageName).putExtra("canSee", canSee).putExtra("screenText", text)) }
    private fun createChannel() { if (Build.VERSION.SDK_INT >= 26) { val nm = getSystemService(NotificationManager::class.java); nm.createNotificationChannel(NotificationChannel(CHANNEL, "NOVA screen sharing", NotificationManager.IMPORTANCE_LOW)) } }
    private fun notification(): Notification { val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this); return builder.setContentTitle("NOVA screen sharing is active").setContentText("Tap Stop in NOVA to end screen capture").setSmallIcon(android.R.drawable.ic_menu_view).setOngoing(true).build() }
    override fun onDestroy() { try { display?.release(); reader?.close(); projection?.stop(); recognizer.close(); worker?.quitSafely() } catch (_: Exception) {}; broadcast(false, ""); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
