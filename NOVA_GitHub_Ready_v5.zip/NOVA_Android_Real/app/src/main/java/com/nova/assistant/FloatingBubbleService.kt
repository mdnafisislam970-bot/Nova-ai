package com.nova.assistant

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView

class FloatingBubbleService : Service() {
    private var windowManager: WindowManager? = null
    private var bubble: TextView? = null
    private var params: WindowManager.LayoutParams? = null
    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        bubble = TextView(this).apply { text = "N"; textSize = 22f; gravity = Gravity.CENTER; setTextColor(0xFFFFFFFF.toInt()); setBackgroundColor(0xFF087F8C.toInt()); contentDescription = "NOVA floating assistant" }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        params = WindowManager.LayoutParams(58, 58, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 18; y = 220 }
        var startX = 0; var startY = 0; var downX = 0f; var downY = 0f
        bubble?.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { startX = params!!.x; startY = params!!.y; downX = event.rawX; downY = event.rawY; true }
                MotionEvent.ACTION_MOVE -> { params!!.x = startX + (event.rawX - downX).toInt(); params!!.y = startY + (event.rawY - downY).toInt(); try { windowManager?.updateViewLayout(v, params) } catch (_: Exception) {}; true }
                MotionEvent.ACTION_UP -> { if (kotlin.math.abs(event.rawX - downX) < 10 && kotlin.math.abs(event.rawY - downY) < 10) { val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP); startActivity(i) }; true }
                else -> true
            }
        }
        try { windowManager?.addView(bubble, params) } catch (_: Exception) { stopSelf() }
    }
    override fun onDestroy() { try { if (bubble?.isAttachedToWindow == true) windowManager?.removeView(bubble) } catch (_: Exception) {}; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
